import math
print('hello world')
print(math.sqrt(2))